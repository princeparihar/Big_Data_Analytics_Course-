import java.sql.*;


class retrieve { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","Prince"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("Select * from week12"); 
           
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 