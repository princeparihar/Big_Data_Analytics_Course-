import java.sql.*;

/**
 * made by sawan
 */
class delete { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","sawan"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("DELETE FROM week12 Where City = 'Delhi';"); 
           
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 