import java.sql.*;

class insert { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","Prince"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("INSERT INTO week12" + 
                "VALUES (101, 'Prince','Parihar','Prince@gmail.com',100000,23,'Delhi')"); 
            st.executeUpdate("INSERT INTO Customers " + 
                "VALUES (101, 'Prince2','Parihar','Prince1@gmail.com',10000,24,'Mumbai')");
            st.executeUpdate("INSERT INTO Customers " + 
                "VALUES (101, 'Prince3','Parihar','Prince2@gmail.com',200000,25,'Chandigarh')");
            st.executeUpdate("INSERT INTO Customers " + 
                "VALUES (101, 'Prince4','Parihar','Prince3@gmail.com',50000,26,'Delhi')");

            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 