import java.sql.*;


class where { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","prince"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("SELECT * FROM week12 WHERE City IN('Delhi','Chandigarh','Mumbai');"); 
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 