import java.sql.*;


class order { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","Prince"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("SELECT * FROM week12 ORDER BY First_Name ASC;"); 
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 