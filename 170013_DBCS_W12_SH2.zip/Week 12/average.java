import java.sql.*;


class average { 
  
    public static void main (String[] args) { 
        try { 
            String url = "jdbc:msql://localhost:3036/sh"; 
            Connection conn = DriverManager.getConnection(url,"root","Prince"); 
            Statement st = conn.createStatement(); 
            st.executeUpdate("SELECT Dept_id, Avg(Salary) FROM week12;"); 
            conn.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
  
    }
} 